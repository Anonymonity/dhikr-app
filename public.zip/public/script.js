let count = Number(localStorage.getItem("dhikrCount")) || 0;

const countSpan = document.getElementById("count");
const btn = document.getElementById("countBtn");

countSpan.textContent = count;

btn.addEventListener("click", () => {
  count++;
  countSpan.textContent = count;
  localStorage.setItem("dhikrCount", count);
});